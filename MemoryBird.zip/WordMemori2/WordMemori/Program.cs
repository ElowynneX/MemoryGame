﻿
using var game = new WordMemori.Game1();
game.Run();
